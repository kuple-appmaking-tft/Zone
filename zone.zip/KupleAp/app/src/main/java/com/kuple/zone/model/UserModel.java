package com.kuple.zone.model;


public class UserModel {
    public String userEmail;
    public String userPassword;
    public String phoneNumber;
    public String nickname;
}

