package com.kuple.zone.board;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.kuple.zone.R;

public class CommonboardActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_commonboard);
    }
}
