package com.kuple.zone.model;

public class ChildModel {
}
